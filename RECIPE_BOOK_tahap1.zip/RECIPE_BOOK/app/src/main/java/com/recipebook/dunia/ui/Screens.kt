@file:OptIn(ExperimentalMaterial3Api::class)

package com.recipebook.dunia.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.recipebook.dunia.data.AppState
import com.recipebook.dunia.data.Category
import com.recipebook.dunia.data.Recipe
import com.recipebook.dunia.data.RecipeRepository
import com.recipebook.dunia.data.RecipeSearch
import java.time.LocalDate
import kotlin.random.Random

@Composable
private fun AppHeader(count: Int) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).background(Coffee, CircleShape), contentAlignment = Alignment.Center) {
            Text("📖", fontSize = 22.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("RECIPE BOOK", fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Coffee, letterSpacing = 1.sp)
            Text("Resep Dunia • $count resep", fontSize = 12.sp, color = Muted)
        }
    }
}

@Composable
fun HomeScreen(
    recipes: List<Recipe>,
    app: AppState,
    query: String,
    onQuery: (String) -> Unit,
    onOpen: (Recipe) -> Unit,
    onCategory: (Category) -> Unit
) {
    val results = remember(query, recipes) { RecipeSearch.search(recipes, query) }
    val popular = remember(recipes) { recipes.filter { it.popular }.ifEmpty { recipes }.take(10) }
    val newest = remember(recipes) { recipes.sortedByDescending { it.added }.take(10) }
    val recommended = remember(recipes) { recipes.shuffled(Random(LocalDate.now().toEpochDay())).take(10) }
    val editor = remember(recipes) { recipes.filter { it.editor }.ifEmpty { recipes }.take(10) }

    Column(Modifier.fillMaxSize().background(Cream)) {
        AppHeader(recipes.size)
        Text(
            "Selamat datang di dunia kuliner",
            modifier = Modifier.padding(horizontal = 16.dp),
            fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Ink
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = query,
            onValueChange = onQuery,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            singleLine = true,
            placeholder = { Text("Cari resep, bahan, atau negara…") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = Muted) },
            trailingIcon = {
                if (query.isNotEmpty()) IconButton(onClick = { onQuery("") }) {
                    Icon(Icons.Filled.Clear, contentDescription = "Hapus", tint = Muted)
                }
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Paper, unfocusedContainerColor = Paper,
                focusedBorderColor = Coffee, unfocusedBorderColor = Line
            )
        )
        Spacer(Modifier.height(6.dp))

        if (query.isNotBlank()) {
            if (results.isEmpty()) {
                EmptyState(
                    "Resep tidak ditemukan",
                    "Coba kata kunci lain, misalnya nama makanan, bahan, atau negara asal."
                )
            } else {
                Text("${results.size} resep ditemukan", modifier = Modifier.padding(horizontal = 16.dp), fontSize = 13.sp, color = Muted)
                RecipeGrid(results, app, onOpen, Modifier.weight(1f))
            }
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 16.dp)) {
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(Category.values().toList(), key = { it.key }) { c ->
                            FilterChip(
                                selected = false,
                                onClick = { onCategory(c) },
                                label = { Text("${c.emoji} ${c.label}") }
                            )
                        }
                    }
                }
                item { SectionTitle("Resep Populer") }
                item { RecipeRow(popular, app, onOpen) }
                item { SectionTitle("Resep Terbaru") }
                item { RecipeRow(newest, app, onOpen) }
                item { SectionTitle("Rekomendasi Untukmu") }
                item { RecipeRow(recommended, app, onOpen) }
                item { SectionTitle("Pilihan Editor") }
                item { RecipeRow(editor, app, onOpen) }
            }
        }
    }
}

@Composable
fun CategoriesScreen(
    recipes: List<Recipe>,
    app: AppState,
    selected: Category?,
    onSelect: (Category?) -> Unit,
    onOpen: (Recipe) -> Unit
) {
    if (selected == null) {
        Column(Modifier.fillMaxSize().background(Cream)) {
            Text(
                "Kategori Resep",
                modifier = Modifier.padding(16.dp),
                fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 24.sp, color = Coffee
            )
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(Category.values().toList(), key = { it.key }) { c ->
                    val n = recipes.count { it.cat == c }
                    Card(
                        onClick = { onSelect(c) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Paper),
                        elevation = CardDefaults.cardElevation(4.dp)
                    ) {
                        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(c.emoji, fontSize = 32.sp)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(c.label, fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink)
                                Text("$n resep", fontSize = 13.sp, color = Muted)
                            }
                        }
                    }
                }
            }
        }
    } else {
        androidx.compose.runtime.key(selected.key) { CategoryDetail(selected, recipes, app, { onSelect(null) }, onOpen) }
    }
}

@Composable
private fun CategoryDetail(
    cat: Category,
    recipes: List<Recipe>,
    app: AppState,
    onBack: () -> Unit,
    onOpen: (Recipe) -> Unit
) {
    val inCat = remember(recipes, cat) { recipes.filter { it.cat == cat } }
    var country by rememberSaveable { mutableStateOf<String?>(null) }
    var time by rememberSaveable { mutableStateOf<String?>(null) }
    var diff by rememberSaveable { mutableStateOf<String?>(null) }
    val countries = remember(inCat) { inCat.map { it.country }.distinct().sorted() }
    val timeOpts = listOf("≤ 30 menit", "31–60 menit", "> 60 menit")
    val diffOpts = listOf("Mudah", "Sedang", "Sulit")

    val shown = inCat.filter { r ->
        (country == null || r.country == country) &&
            (diff == null || r.difficulty == diff) &&
            when (time) {
                timeOpts[0] -> r.minutes <= 30
                timeOpts[1] -> r.minutes in 31..60
                timeOpts[2] -> r.minutes > 60
                else -> true
            }
    }

    Column(Modifier.fillMaxSize().background(Cream)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali", tint = Coffee) }
            Text(
                "${cat.emoji} ${cat.label}",
                modifier = Modifier.weight(1f),
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 19.sp, color = Coffee
            )
        }
        FilterBar {
            FilterDropdown("Negara", countries, country) { country = it }
            FilterDropdown("Waktu", timeOpts, time) { time = it }
            FilterDropdown("Tingkat", diffOpts, diff) { diff = it }
        }
        Text("${shown.size} resep", modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp), fontSize = 13.sp, color = Muted)
        if (shown.isEmpty()) {
            EmptyState("Tidak ada resep", "Tidak ada resep yang cocok dengan filter ini. Coba ubah filternya.")
        } else {
            RecipeGrid(shown, app, onOpen, Modifier.weight(1f))
        }
    }
}

@Composable
fun FavoritesScreen(recipes: List<Recipe>, app: AppState, onOpen: (Recipe) -> Unit) {
    val favs = app.favorites.mapNotNull { id -> recipes.firstOrNull { it.id == id } }
    Column(Modifier.fillMaxSize().background(Cream)) {
        Text(
            "Resep Favorit",
            modifier = Modifier.padding(16.dp),
            fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 24.sp, color = Coffee
        )
        if (favs.isEmpty()) {
            EmptyState(
                "Belum ada favorit",
                "Ketuk ikon hati pada resep untuk menyimpannya di sini. Favorit tersimpan di HP dan tetap ada walau aplikasi ditutup."
            )
        } else {
            RecipeGrid(favs, app, onOpen, Modifier.weight(1f))
        }
    }
}

@Composable
fun ProfileScreen(recipes: List<Recipe>, app: AppState) {
    val context = LocalContext.current
    val credits = remember { RecipeRepository.credits(context) }
    var showCredits by rememberSaveable { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().background(Cream).verticalScroll(rememberScrollState()).padding(16.dp)
    ) {
        Text("Profil", fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 24.sp, color = Coffee)
        Spacer(Modifier.height(12.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Paper)
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("📖 RECIPE BOOK", fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Coffee)
                Spacer(Modifier.height(4.dp))
                Text("Buku resep digital yang bisa dibaca sepenuhnya tanpa internet.", fontSize = 13.sp, color = Muted)
                Spacer(Modifier.height(12.dp))
                Text("${recipes.size} resep tersedia • ${app.favorites.size} favorit", fontSize = 14.sp, color = Ink)
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Paper)
        ) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Teks buku lebih besar", fontWeight = FontWeight.Medium, color = Ink)
                    Text("Memperbesar huruf di halaman buku resep", fontSize = 12.sp, color = Muted)
                }
                Switch(
                    checked = app.largeText.value,
                    onCheckedChange = { app.setLargeText(it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = Olive)
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(
            onClick = { showCredits = !showCredits },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Paper)
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("Kredit foto (${credits.size})", fontWeight = FontWeight.Medium, color = Ink)
                Text("Foto makanan bersumber dari Wikimedia Commons dengan lisensi terbuka.", fontSize = 12.sp, color = Muted)
                if (showCredits) {
                    Spacer(Modifier.height(10.dp))
                    credits.forEach { c ->
                        Text(
                            "${c.title} — ${c.author} (${c.license})",
                            fontSize = 11.sp, color = Muted, modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
