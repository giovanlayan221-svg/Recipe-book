package com.recipebook.dunia.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.recipebook.dunia.data.AppState
import com.recipebook.dunia.data.Recipe

sealed interface BookPage {
    data object Cover : BookPage
    data class Ingredients(val items: List<List<String>>, val part: Int, val parts: Int, val alt: List<String>) : BookPage
    data class Steps(val startNo: Int, val items: List<String>, val tips: List<String>) : BookPage
    data object Closing : BookPage
}

fun buildPages(r: Recipe): List<BookPage> {
    val pages = mutableListOf<BookPage>(BookPage.Cover)
    val ing = r.ingredients.chunked(8)
    ing.forEachIndexed { i, chunk ->
        pages += BookPage.Ingredients(chunk, i + 1, ing.size, if (i == ing.lastIndex) r.alt else emptyList())
    }
    val st = r.steps.chunked(3)
    var no = 1
    st.forEachIndexed { i, chunk ->
        pages += BookPage.Steps(no, chunk, if (i == st.lastIndex) r.tips else emptyList())
        no += chunk.size
    }
    pages += BookPage.Closing
    return pages
}

private fun fs(v: Float, sc: Float): TextUnit = (v * sc).sp

@Composable
fun BookScreen(recipe: Recipe, app: AppState, onClose: () -> Unit) {
    val pages = remember(recipe.id) { buildPages(recipe) }
    var page by rememberSaveable(recipe.id) { mutableIntStateOf(0) }
    val sc = if (app.largeText.value) 1.18f else 1f
    val fav = app.isFav(recipe.id)

    Column(
        Modifier
            .fillMaxSize()
            .background(Cream)
            .systemBarsPadding()
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali ke katalog", tint = Coffee)
            }
            Text(
                recipe.name,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontFamily = Serif,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Coffee
            )
            IconButton(onClick = { app.toggleFavorite(recipe.id) }) {
                Icon(
                    if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = "Favorit",
                    tint = if (fav) Color(0xFFC0392B) else Coffee
                )
            }
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp)
                .shadow(10.dp, RoundedCornerShape(6.dp))
        ) {
            PageCurl(
                pageCount = pages.size,
                page = page,
                onPageChange = { page = it },
                modifier = Modifier.fillMaxSize()
            ) { i ->
                PageFrame(i + 1, pages.size) {
                    when (val pg = pages[i]) {
                        is BookPage.Cover -> CoverPage(recipe, sc)
                        is BookPage.Ingredients -> IngredientsPage(recipe, pg, sc)
                        is BookPage.Steps -> StepsPage(pg, sc)
                        is BookPage.Closing -> ClosingPage(recipe, app, sc, onClose)
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            pages.indices.forEach { i ->
                Box(
                    Modifier
                        .padding(horizontal = 3.dp)
                        .size(if (i == page) 9.dp else 6.dp)
                        .background(if (i == page) Coffee else Color(0xFFD8C9B0), CircleShape)
                )
            }
            Spacer(Modifier.width(12.dp))
            Text("Halaman ${page + 1} dari ${pages.size}", fontSize = 12.sp, color = Muted)
        }
    }
}

@Composable
private fun PageFrame(no: Int, total: Int, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Paper)) {
        Column(Modifier.weight(1f).fillMaxWidth(), content = content)
        Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
            Text("— $no / $total —", color = Muted, fontSize = 11.sp, fontFamily = Serif)
        }
    }
}

@Composable
private fun InfoChip(text: String) {
    Box(
        Modifier
            .background(Color(0xFFF1E8D6), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) { Text(text, fontSize = 12.sp, color = Coffee, fontWeight = FontWeight.Medium) }
}

@Composable
private fun CoverPage(r: Recipe, sc: Float) {
    Column(Modifier.fillMaxSize()) {
        AsyncImage(
            model = r.imagePath,
            contentDescription = r.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().weight(1.15f).background(Color(0xFFE9DCC3))
        )
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(18.dp)
        ) {
            Text(r.cat.label.uppercase(), fontSize = 11.sp, color = Olive, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Text(r.name, fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = fs(26f, sc), color = Coffee, lineHeight = fs(31f, sc))
            Text("📍 ${r.country}", fontSize = fs(13f, sc), color = Muted)
            Spacer(Modifier.height(8.dp))
            Text(r.desc, fontSize = fs(14f, sc), lineHeight = fs(21f, sc), color = Ink)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                InfoChip("⏱ ${r.minutes} menit")
                InfoChip("⭐ ${r.difficulty}")
                InfoChip("🍽 ${r.servings} porsi")
            }
        }
    }
}

@Composable
private fun IngredientsPage(r: Recipe, pg: BookPage.Ingredients, sc: Float) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text("Bahan-bahan", fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = fs(24f, sc), color = Coffee)
        val part = if (pg.parts > 1) " • bagian ${pg.part}/${pg.parts}" else ""
        Text("Untuk ${r.servings} porsi$part", fontSize = fs(12f, sc), color = Muted)
        Spacer(Modifier.height(8.dp))
        HorizontalDivider(color = Line)
        pg.items.forEach { row ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
                Text("•", color = Olive, fontWeight = FontWeight.Bold, fontSize = fs(16f, sc))
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(row.getOrElse(0) { "" }, fontSize = fs(15f, sc), color = Ink, fontWeight = FontWeight.Medium)
                    val q = row.getOrElse(1) { "" }
                    if (q.isNotBlank()) Text(q, fontSize = fs(13f, sc), color = Muted)
                }
            }
        }
        if (pg.alt.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Text("Alternatif bahan di Indonesia", fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = fs(17f, sc), color = Olive)
            Spacer(Modifier.height(4.dp))
            pg.alt.forEach { Text("• $it", fontSize = fs(13.5f, sc), lineHeight = fs(19f, sc), color = Ink, modifier = Modifier.padding(vertical = 2.dp)) }
        }
    }
}

@Composable
private fun StepsPage(pg: BookPage.Steps, sc: Float) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text("Cara Memasak", fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = fs(24f, sc), color = Coffee)
        Spacer(Modifier.height(8.dp))
        HorizontalDivider(color = Line)
        pg.items.forEachIndexed { i, s ->
            Row(Modifier.fillMaxWidth().padding(vertical = 9.dp)) {
                Box(Modifier.size(28.dp).background(Olive, CircleShape), contentAlignment = Alignment.Center) {
                    Text("${pg.startNo + i}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Spacer(Modifier.width(10.dp))
                Text(s, fontSize = fs(14.5f, sc), lineHeight = fs(21f, sc), color = Ink, modifier = Modifier.weight(1f))
            }
        }
        if (pg.tips.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Column(
                Modifier.fillMaxWidth().background(Color(0xFFF3F0DF), RoundedCornerShape(14.dp)).padding(14.dp)
            ) {
                Text("💡 Tips agar tidak gagal", fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = fs(16f, sc), color = Olive)
                Spacer(Modifier.height(4.dp))
                pg.tips.forEach { Text("• $it", fontSize = fs(13.5f, sc), lineHeight = fs(19f, sc), color = Ink, modifier = Modifier.padding(vertical = 2.dp)) }
            }
        }
    }
}

@Composable
private fun ClosingPage(r: Recipe, app: AppState, sc: Float, onClose: () -> Unit) {
    val fav = app.isFav(r.id)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text("Penyajian & Variasi", fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = fs(24f, sc), color = Coffee)
        Spacer(Modifier.height(8.dp))
        HorizontalDivider(color = Line)
        if (r.serve.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text("Tips penyajian", fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = fs(17f, sc), color = Olive)
            Text(r.serve, fontSize = fs(14f, sc), lineHeight = fs(20f, sc), color = Ink)
        }
        if (r.variations.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text("Variasi resep", fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = fs(17f, sc), color = Olive)
            r.variations.forEach { Text("• $it", fontSize = fs(14f, sc), lineHeight = fs(20f, sc), color = Ink, modifier = Modifier.padding(vertical = 2.dp)) }
        }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { app.toggleFavorite(r.id) },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = if (fav) Olive else Coffee)
        ) {
            Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(if (fav) "Tersimpan di Favorit" else "Simpan ke Favorit")
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onClose, modifier = Modifier.fillMaxWidth()) {
            Text("Kembali ke katalog resep", color = Coffee)
        }
    }
}
