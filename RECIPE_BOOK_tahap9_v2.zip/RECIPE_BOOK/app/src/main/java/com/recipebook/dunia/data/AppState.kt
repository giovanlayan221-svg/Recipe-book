package com.recipebook.dunia.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf

/** Penyimpanan lokal: daftar favorit dan pengaturan pengguna (SharedPreferences). */
class AppState(context: Context) {
    private val prefs = context.getSharedPreferences("recipebook", Context.MODE_PRIVATE)

    val favorites = mutableStateListOf<String>().also { list ->
        prefs.getString("fav", "").orEmpty().split("|").filter { it.isNotBlank() }.forEach { list.add(it) }
    }
    val largeText = mutableStateOf(prefs.getBoolean("large", false))

    fun isFav(id: String): Boolean = favorites.contains(id)

    fun toggleFavorite(id: String) {
        if (!favorites.remove(id)) favorites.add(0, id)
        prefs.edit().putString("fav", favorites.joinToString("|")).apply()
    }

    fun setLargeText(value: Boolean) {
        largeText.value = value
        prefs.edit().putBoolean("large", value).apply()
    }
}
