package com.recipebook.dunia.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

val Cream = Color(0xFFFBF5E9)
val Paper = Color(0xFFFFFCF5)
val Coffee = Color(0xFF5B3A29)
val Olive = Color(0xFF6B7A3A)
val Ink = Color(0xFF2E2118)
val Muted = Color(0xFF8A7767)
val Line = Color(0xFFE6DAC6)
val Serif = FontFamily.Serif

@Composable
fun RecipeBookTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Coffee,
            onPrimary = Color.White,
            secondary = Olive,
            onSecondary = Color.White,
            background = Cream,
            onBackground = Ink,
            surface = Paper,
            onSurface = Ink,
            surfaceVariant = Color(0xFFF1E8D6),
            secondaryContainer = Color(0xFFE9EBD3),
            onSecondaryContainer = Ink
        ),
        content = content
    )
}
