package com.recipebook.dunia

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.recipebook.dunia.data.AppState
import com.recipebook.dunia.data.Category
import com.recipebook.dunia.data.Recipe
import com.recipebook.dunia.data.RecipeRepository
import com.recipebook.dunia.ui.BookScreen
import com.recipebook.dunia.ui.CategoriesScreen
import com.recipebook.dunia.ui.Coffee
import com.recipebook.dunia.ui.Cream
import com.recipebook.dunia.ui.FavoritesScreen
import com.recipebook.dunia.ui.HomeScreen
import com.recipebook.dunia.ui.Muted
import com.recipebook.dunia.ui.Paper
import com.recipebook.dunia.ui.ProfileScreen
import com.recipebook.dunia.ui.RecipeBookTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = AppState(applicationContext)
        setContent { RecipeBookTheme { Root(app) } }
    }
}

@Composable
private fun Root(app: AppState) {
    val context = LocalContext.current
    var recipes by remember { mutableStateOf<List<Recipe>?>(null) }
    LaunchedEffect(Unit) {
        recipes = withContext(Dispatchers.IO) { RecipeRepository.load(context) }
    }
    val list = recipes
    if (list == null) {
        Box(Modifier.fillMaxSize().background(Cream), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Coffee)
        }
    } else {
        MainContent(list, app)
    }
}

@Composable
private fun MainContent(recipes: List<Recipe>, app: AppState) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var catKey by rememberSaveable { mutableStateOf<String?>(null) }
    var openId by rememberSaveable { mutableStateOf<String?>(null) }
    var query by rememberSaveable { mutableStateOf("") }
    val open = recipes.firstOrNull { it.id == openId }
    val tabs = listOf("Beranda" to Icons.Filled.Home, "Kategori" to Icons.Filled.Menu, "Favorit" to Icons.Filled.Favorite, "Profil" to Icons.Filled.Person)

    BackHandler(enabled = open != null || (tab == 1 && catKey != null) || tab != 0) {
        when {
            open != null -> openId = null
            tab == 1 && catKey != null -> catKey = null
            else -> tab = 0
        }
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = Cream,
            bottomBar = {
                NavigationBar(containerColor = Paper) {
                    tabs.forEachIndexed { i, (label, icon) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = Coffee,
                                indicatorColor = Coffee,
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { inner ->
            Box(Modifier.padding(inner).fillMaxSize()) {
                when (tab) {
                    0 -> HomeScreen(
                        recipes, app, query, { query = it },
                        onOpen = { openId = it.id },
                        onCategory = { tab = 1; catKey = it.key }
                    )
                    1 -> CategoriesScreen(
                        recipes, app, catKey?.let { Category.fromKey(it) },
                        onSelect = { catKey = it?.key },
                        onOpen = { openId = it.id }
                    )
                    2 -> FavoritesScreen(recipes, app) { openId = it.id }
                    else -> ProfileScreen(recipes, app)
                }
            }
        }
        if (open != null) {
            BookScreen(open, app) { openId = null }
        }
    }
}
