package com.recipebook.dunia.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.launch

/**
 * Efek membalik halaman (page curl): halaman terlipat di sepanjang garis lipatan yang miring
 * mengikuti posisi jari, lengkap dengan bagian belakang kertas, gradasi lengkungan, dan bayangan.
 * Geser kiri = halaman berikutnya, geser kanan = halaman sebelumnya; ketuk tepi kiri/kanan juga membalik.
 */
@Composable
fun PageCurl(
    pageCount: Int,
    page: Int,
    onPageChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable (Int) -> Unit
) {
    val scope = rememberCoroutineScope()
    var turning by remember { mutableIntStateOf(-1) } // indeks halaman yang sedang dibalik
    var p by remember { mutableFloatStateOf(0f) }     // 0 = halaman utuh, 1 = halaman sudah terbalik
    var touchY by remember { mutableFloatStateOf(0.65f) }
    var busy by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf(false) }
    val curPage by rememberUpdatedState(page)
    val curCount by rememberUpdatedState(pageCount)
    val change by rememberUpdatedState(onPageChange)

    fun finish(target: Float) {
        val t = turning
        if (t < 0) return
        busy = true
        scope.launch {
            animate(p, target, animationSpec = tween(330, easing = FastOutSlowInEasing)) { v, _ -> p = v }
            p = target
            change(if (target >= 1f) t + 1 else t)
            turning = -1
            p = 0f
            busy = false
        }
    }

    fun tapTurn(forward: Boolean) {
        if (busy || turning != -1) return
        if (forward && curPage < curCount - 1) {
            turning = curPage; p = 0f; touchY = 0.8f; finish(1f)
        } else if (!forward && curPage > 0) {
            turning = curPage - 1; p = 1f; touchY = 0.8f; finish(0f)
        }
    }

    Box(
        modifier
            .clipToBounds()
            .pointerInput(Unit) {
                detectTapGestures { off ->
                    if (off.x > size.width * 0.74f) tapTurn(true)
                    else if (off.x < size.width * 0.26f) tapTurn(false)
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { off ->
                        touchY = (off.y / size.height).coerceIn(0.15f, 0.9f)
                        dragging = !busy && turning == -1
                    },
                    onDragEnd = {
                        if (dragging && turning != -1) finish(if (p > 0.5f) 1f else 0f)
                        dragging = false
                    },
                    onDragCancel = {
                        if (dragging && turning != -1) finish(if (p > 0.5f) 1f else 0f)
                        dragging = false
                    },
                    onHorizontalDrag = { ch, dx ->
                        if (dragging) {
                            touchY = (ch.position.y / size.height).coerceIn(0.15f, 0.9f)
                            if (turning == -1) {
                                if (dx < 0 && curPage < curCount - 1) { turning = curPage; p = 0f }
                                else if (dx > 0 && curPage > 0) { turning = curPage - 1; p = 1f }
                            }
                            if (turning != -1) p = (p - dx / size.width * 1.15f).coerceIn(0f, 1f)
                            ch.consume()
                        }
                    }
                )
            }
    ) {
        val bottomIndex = if (turning == -1) page else turning + 1
        key(bottomIndex) { Box(Modifier.fillMaxSize()) { content(bottomIndex) } }

        if (turning != -1) {
            val t = turning
            key(t) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .drawWithContent {
                            val g = Geo.of(size.width, size.height, p, touchY)
                            clipPath(g.leftPath()) { this@drawWithContent.drawContent() }
                        }
                ) { content(t) }
            }
            Canvas(Modifier.fillMaxSize()) { drawCurl(p, touchY) }
        }
    }
}

private class Geo(val xt: Float, val xb: Float, val w: Float, val h: Float, val fx: Float) {
    fun leftPath() = Path().apply {
        moveTo(0f, 0f); lineTo(xt, 0f); lineTo(xb, h); lineTo(0f, h); close()
    }

    fun rightPath() = Path().apply {
        moveTo(xt, 0f); lineTo(w, 0f); lineTo(w, h); lineTo(xb, h); close()
    }

    /** Bagian belakang kertas = bagian kanan halaman yang dicerminkan terhadap garis lipatan. */
    fun flapPath(): Path {
        val a = Offset(xt, 0f)
        val b = Offset(xb, h)
        val r1 = reflect(Offset(w, 0f), a, b)
        val r2 = reflect(Offset(w, h), a, b)
        return Path().apply {
            moveTo(xt, 0f); lineTo(r1.x, r1.y); lineTo(r2.x, r2.y); lineTo(xb, h); close()
        }
    }

    companion object {
        fun of(w: Float, h: Float, p: Float, ty: Float): Geo {
            val fx = w * (1f - p)
            val tilt = (ty - 0.5f) * 0.3f * minOf(fx, w - fx)
            return Geo(fx + tilt, fx - tilt, w, h, fx)
        }

        private fun reflect(pt: Offset, a: Offset, b: Offset): Offset {
            val dx = b.x - a.x
            val dy = b.y - a.y
            val l2 = dx * dx + dy * dy
            val tt = ((pt.x - a.x) * dx + (pt.y - a.y) * dy) / l2
            val qx = a.x + tt * dx
            val qy = a.y + tt * dy
            return Offset(2 * qx - pt.x, 2 * qy - pt.y)
        }
    }
}

private val ShadowDark = Color(0x66000000)
private val ShadowSoft = Color(0x40000000)
private val PaperBack = Color(0xFFF4EBD8)
private val PaperLight = Color(0xFFFFFBF0)
private val FoldShade = Color(0xFFC9B79A)

private fun DrawScope.drawCurl(p: Float, ty: Float) {
    if (p <= 0.003f || p >= 0.997f) return
    val w = size.width
    val h = size.height
    val g = Geo.of(w, h, p, ty)
    val fx = g.fx

    // 1. Bayangan lipatan jatuh pada halaman di bawahnya
    clipPath(g.rightPath()) {
        drawRect(
            brush = Brush.horizontalGradient(listOf(ShadowDark, Color.Transparent), startX = fx, endX = fx + w * 0.3f),
            topLeft = Offset(fx - 40f, 0f),
            size = Size(w * 0.3f + 80f, h)
        )
    }

    // 2. Bagian belakang kertas dengan gradasi lengkungan di dekat lipatan
    val flapW = (w - fx).coerceAtLeast(1f)
    drawPath(
        path = g.flapPath(),
        brush = Brush.horizontalGradient(
            0f to PaperBack,
            0.55f to PaperLight,
            0.88f to PaperBack,
            1f to FoldShade,
            startX = fx - flapW,
            endX = fx
        )
    )

    // 3. Bayangan tepi kertas yang terlipat jatuh pada halaman depan
    val edge = fx - flapW
    if (edge > 0f) {
        val sw = w * 0.09f
        clipPath(g.leftPath()) {
            drawRect(
                brush = Brush.horizontalGradient(listOf(Color.Transparent, ShadowSoft), startX = edge - sw, endX = edge),
                topLeft = Offset(edge - sw, 0f),
                size = Size(sw, h)
            )
        }
    }

    // 4. Garis lipatan yang mengkilap
    drawLine(Color(0x66FFFFFF), Offset(g.xt, 0f), Offset(g.xb, h), strokeWidth = 2f)
}
