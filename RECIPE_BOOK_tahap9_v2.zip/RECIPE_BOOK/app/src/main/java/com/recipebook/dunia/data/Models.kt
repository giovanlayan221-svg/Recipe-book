package com.recipebook.dunia.data

import kotlinx.serialization.Serializable

enum class Category(val key: String, val label: String, val emoji: String) {
    INDONESIA("indonesia", "Masakan Indonesia", "🍛"),
    ASIA("asia", "Masakan Asia", "🍜"),
    BARAT("barat", "Masakan Barat dan Eropa", "🍝"),
    VIRAL("viral", "Resep Viral dan Kekinian", "🔥"),
    MINUMAN("minuman", "Minuman", "🥤"),
    DESSERT("dessert", "Dessert dan Camilan", "🍰");

    companion object {
        fun fromKey(k: String): Category? = values().firstOrNull { it.key == k }
    }
}

@Serializable
data class Recipe(
    val id: String,
    val name: String,
    val category: String,
    val country: String,
    val desc: String,
    val minutes: Int,
    val difficulty: String,
    val servings: Int,
    val ingredients: List<List<String>>,
    val alt: List<String> = emptyList(),
    val steps: List<String>,
    val tips: List<String> = emptyList(),
    val serve: String = "",
    val variations: List<String> = emptyList(),
    val popular: Boolean = false,
    val editor: Boolean = false,
    val added: String = "2026-01-01",
    val photo: String = "",
    val photoAlt: List<String> = emptyList()
) {
    val cat: Category get() = Category.fromKey(category) ?: Category.INDONESIA
    val imagePath: String get() = "file:///android_asset/images/$id.webp"
}

@Serializable
data class Credit(
    val id: String,
    val title: String = "",
    val author: String = "",
    val license: String = "",
    val url: String = ""
)
