#!/usr/bin/env python3
"""Validasi data resep sebelum build: kolom wajib, duplikat id, kategori, dan isi minimal."""
import glob, json, sys, collections

CATS = {"indonesia", "asia", "barat", "viral", "minuman", "dessert"}
DIFF = {"Mudah", "Sedang", "Sulit"}
errors, seen, names = [], set(), set()
count = collections.Counter()

for path in sorted(glob.glob("app/src/main/assets/recipes/*.json")):
    try:
        data = json.load(open(path, encoding="utf-8"))
    except Exception as e:
        errors.append(f"{path}: JSON rusak ({e})"); continue
    for r in data:
        rid = r.get("id", "?")
        def bad(msg): errors.append(f"{path} [{rid}]: {msg}")
        for k in ("id", "name", "category", "country", "desc", "minutes", "difficulty", "servings", "ingredients", "steps", "photo"):
            if not r.get(k): bad(f"kolom '{k}' kosong")
        if r.get("category") not in CATS: bad("kategori tidak valid")
        if r.get("difficulty") not in DIFF: bad("tingkat kesulitan tidak valid")
        if rid in seen: bad("id duplikat")
        if r.get("name", "").lower() in names: bad("nama duplikat")
        seen.add(rid); names.add(r.get("name", "").lower())
        if any(not (isinstance(i, list) and len(i) == 2 and all(isinstance(x, str) and x for x in i)) for i in r.get("ingredients", [])):
            bad("bahan harus berupa pasangan [nama, takaran]")
        if len(r.get("ingredients", [])) < 4: bad("bahan kurang dari 4")
        if len(r.get("steps", [])) < 4: bad("langkah kurang dari 4")
        if not r.get("tips"): bad("tips kosong")
        count[r.get("category")] += 1

print("Jumlah resep per kategori:", dict(count), "| total:", sum(count.values()))
if errors:
    print("\n".join(errors)); sys.exit(1)
print("Validasi resep OK")
