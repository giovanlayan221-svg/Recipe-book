#!/usr/bin/env python3
"""
Mengambil foto makanan dari Wikimedia Commons saat build (hanya lisensi terbuka:
CC0, domain publik, CC BY, CC BY-SA), mengecilkannya ke WebP, dan menyimpan ke
app/src/main/assets/images/<id>.webp. Kredit foto ditulis ke assets/credits.json.
Resep tanpa foto tetap tampil di aplikasi dengan latar polos. Foto yang salah bisa diperbaiki lewat\ntools/photo_overrides.json (pilih file manual) atau tools/photo_blocklist.json (tolak file tertentu).
"""
import glob, io, json, math, os, re, sys, time, unicodedata, urllib.parse, urllib.request
from PIL import Image

ASSETS = "app/src/main/assets"
IMG_DIR = f"{ASSETS}/images"
API = "https://commons.wikimedia.org/w/api.php"
UA = "RecipeBookBuild/1.0 (offline recipe app build script; contact via GitHub repo)"
BAD_WORDS = ("logo", "map", "flag", "icon", "diagram", "poster", "cover", "pdf", "statue",
             "painting", "stamp", "drawing", "illustration", "menu", "sign", "vector",
             "market", "stall", "vendor", "shop", "store", "restaurant", "kitchen", "chef",
             "people", "woman", "man", "girl", "boy", "child", "museum", "machine", "package",
             "packaging", "bottle", "factory", "street", "festival", "ingredients", "plant", "tree")
# Kata umum yang tidak membedakan makanan; tidak dihitung saat mencocokkan judul foto.
GENERIC = {"kue", "jus", "es", "sup", "sop", "soup", "dan", "and", "with", "the", "food", "dish",
           "resep", "recipe", "cake", "juice", "drink", "indonesian", "indonesia"}
OVERRIDES_FILE = "tools/photo_overrides.json"   # {"id-resep": "File:Nama persis di Commons.jpg"}
BLOCKLIST_FILE = "tools/photo_blocklist.json"   # {"id-resep": ["potongan judul foto yang salah", ...]}
OK_LIC = ("cc0", "cc by", "cc-by", "public domain", "pd")


def http_get(url, retries=4):
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=40) as r:
                return r.read()
        except Exception as e:
            wait = 2 * (i + 1)
            print(f"   (percobaan {i+1} gagal: {e}; tunggu {wait}s)")
            time.sleep(wait)
    return None


def license_ok(lic):
    l = lic.lower().replace("-", " ")
    if re.search(r"\b(nc|nd)\b", l):
        return False
    return any(l.startswith(p.replace("-", " ")) for p in OK_LIC)


def norm(s):
    s = unicodedata.normalize("NFKD", s.lower())
    return "".join(c for c in s if not unicodedata.combining(c))


def tokens_of(query):
    allt = re.findall(r"[a-z]+", norm(query))
    toks = [t for t in allt if len(t) >= 3 and t not in GENERIC]
    return toks or [t for t in allt if len(t) >= 2]   # nama pendek seperti "Kue Ku"


def title_score(title, query):
    """Skor 0..1+: seberapa cocok judul file Commons dengan kata kunci. 0 = tolak."""
    toks = tokens_of(query)
    if not toks:
        return 0.0
    t = norm(title)
    words = set(re.findall(r"[a-z]+", t))
    hit = sum(1 for k in toks if k in words or any(w.startswith(k) for w in words))
    need = max(1, math.ceil(0.6 * len(toks)))
    if hit < need:
        return 0.0
    phrase = " ".join(re.findall(r"[a-z]+", norm(query)))
    bonus = 0.5 if phrase and phrase in " ".join(re.findall(r"[a-z]+", t)) else 0.0
    return hit / len(toks) + bonus


def strip_html(s):
    return re.sub(r"<[^>]+>", "", s or "").strip()


def search(query):
    params = {
        "action": "query", "format": "json", "generator": "search",
        "gsrsearch": f"{query} filetype:bitmap", "gsrnamespace": "6", "gsrlimit": "15",
        "prop": "imageinfo", "iiprop": "url|size|mime|extmetadata", "iiurlwidth": "720",
    }
    raw = http_get(API + "?" + urllib.parse.urlencode(params))
    if not raw:
        return []
    pages = json.loads(raw).get("query", {}).get("pages", {})
    return sorted(pages.values(), key=lambda p: p.get("index", 999))


def make_hit(page):
    info = (page.get("imageinfo") or [None])[0]
    if not info:
        return None
    meta = info.get("extmetadata", {})
    lic = meta.get("LicenseShortName", {}).get("value", "")
    return {
        "url": info.get("thumburl") or info.get("url"),
        "title": page["title"].replace("File:", ""),
        "author": strip_html(meta.get("Artist", {}).get("value", "")) or "Wikimedia Commons",
        "license": lic,
        "page": info.get("descriptionurl", ""),
    }


def pick(query, blocked=()):
    """Pilih foto TERBAIK (bukan sekadar yang pertama) dengan judul yang benar-benar cocok."""
    best, best_score = None, 0.0
    for page in search(query):
        info = (page.get("imageinfo") or [None])[0]
        if not info or info.get("mime") not in ("image/jpeg", "image/png"):
            continue
        if info.get("width", 0) < 700 or info.get("height", 0) < 450:
            continue
        title = page.get("title", "")
        words = set(re.findall(r"[a-z]+", norm(title)))
        if any(b in words for b in BAD_WORDS):
            continue
        if any(b.lower() in title.lower() for b in blocked):
            continue
        meta = info.get("extmetadata", {})
        if not license_ok(meta.get("LicenseShortName", {}).get("value", "")):
            continue
        sc = title_score(title, query) - 0.01 * page.get("index", 0)
        if title_score(title, query) > 0 and sc > best_score:
            best, best_score = page, sc
    return make_hit(best) if best else None


def fetch_by_title(file_title):
    """Ambil foto yang ditentukan manual (nama file persis di Commons)."""
    if not file_title.lower().startswith("file:"):
        file_title = "File:" + file_title
    params = {"action": "query", "format": "json", "titles": file_title,
              "prop": "imageinfo", "iiprop": "url|size|mime|extmetadata", "iiurlwidth": "720"}
    raw = http_get(API + "?" + urllib.parse.urlencode(params))
    if not raw:
        return None
    for page in json.loads(raw).get("query", {}).get("pages", {}).values():
        hit = make_hit(page)
        if hit and license_ok(hit["license"]):
            return hit
    return None


def save_webp(data, path):
    im = Image.open(io.BytesIO(data)).convert("RGB")
    if im.width > 720:
        im = im.resize((720, int(im.height * 720 / im.width)), Image.LANCZOS)
    im.save(path, "WEBP", quality=74, method=6)


def main():
    os.makedirs(IMG_DIR, exist_ok=True)
    cred_path = f"{ASSETS}/credits.json"
    credits = {}
    if os.path.exists(cred_path):
        for c in json.load(open(cred_path, encoding="utf-8")):
            credits[c["id"]] = c

    overrides = json.load(open(OVERRIDES_FILE, encoding="utf-8")) if os.path.exists(OVERRIDES_FILE) else {}
    blocklist = json.load(open(BLOCKLIST_FILE, encoding="utf-8")) if os.path.exists(BLOCKLIST_FILE) else {}
    ok, missing, used = 0, [], []
    for path in sorted(glob.glob(f"{ASSETS}/recipes/*.json")):
        for r in json.load(open(path, encoding="utf-8")):
            rid, out = r["id"], f"{IMG_DIR}/{r['id']}.webp"
            if rid in overrides:
                print(f"[{rid}] foto manual: {overrides[rid]}")
                hit = fetch_by_title(overrides[rid])
                data = http_get(hit["url"]) if hit else None
                if data:
                    try:
                        save_webp(data, out)
                        credits[rid] = {"id": rid, "title": hit["title"], "author": hit["author"],
                                        "license": hit["license"], "url": hit["page"]}
                        used.append(f"{rid}\t{hit['title']} (manual)")
                        ok += 1; continue
                    except Exception as e:
                        print(f"   gagal konversi: {e}")
                print("   foto manual gagal, pakai pencarian otomatis")
            if os.path.exists(out):
                ok += 1; continue
            queries = [r.get("photo", "")] + r.get("photoAlt", []) + [r["name"]]
            done = False
            for q in [q for q in queries if q]:
                print(f"[{rid}] cari: {q}")
                hit = pick(q, blocklist.get(rid, []))
                time.sleep(0.6)
                if not hit:
                    continue
                data = http_get(hit["url"])
                if not data:
                    continue
                try:
                    save_webp(data, out)
                except Exception as e:
                    print(f"   gagal konversi: {e}"); continue
                credits[rid] = {"id": rid, "title": hit["title"], "author": hit["author"],
                                "license": hit["license"], "url": hit["page"]}
                print(f"   OK -> {hit['title']} ({hit['license']})")
                used.append(f"{rid}\t{hit['title']}")
                ok += 1; done = True
                break
            if not done:
                missing.append(rid)

    json.dump(list(credits.values()), open(cred_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    with open("build_report.txt", "w", encoding="utf-8") as f:
        f.write(f"Foto berhasil: {ok}\nResep tanpa foto (tampil dengan latar polos): {len(missing)}\n")
        f.write("\n".join(missing) + "\n\n=== FOTO YANG DIPAKAI (id <tab> judul file Commons) ===\n")
        f.write("\n".join(sorted(used)) + "\n")
    print(f"\nFoto berhasil: {ok} | tanpa foto: {len(missing)} -> {missing}")
    if ok == 0:
        print("Tidak ada foto yang berhasil diunduh (cek koneksi runner)."); sys.exit(1)


if __name__ == "__main__":
    main()
