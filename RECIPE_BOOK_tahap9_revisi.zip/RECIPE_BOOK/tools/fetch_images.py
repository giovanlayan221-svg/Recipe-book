#!/usr/bin/env python3
"""
Mengambil foto makanan dari Wikimedia Commons saat build (hanya lisensi terbuka:
CC0, domain publik, CC BY, CC BY-SA), mengecilkannya ke WebP, dan menyimpan ke
app/src/main/assets/images/<id>.webp. Kredit foto ditulis ke assets/credits.json.
Resep yang tidak mendapat foto TIDAK dimasukkan ke aplikasi (tidak ada placeholder).
"""
import glob, io, json, os, re, sys, time, urllib.parse, urllib.request
from PIL import Image

ASSETS = "app/src/main/assets"
IMG_DIR = f"{ASSETS}/images"
API = "https://commons.wikimedia.org/w/api.php"
UA = "RecipeBookBuild/1.0 (offline recipe app build script; contact via GitHub repo)"
BAD_WORDS = ("logo", "map", "flag", "icon", "diagram", "poster", "cover", "pdf", "statue",
             "painting", "stamp", "drawing", "illustration", "menu", "sign", "vector")
OK_LIC = ("cc0", "cc by", "cc-by", "public domain", "pd")


def http_get(url, retries=4):
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=40) as r:
                return r.read()
        except Exception as e:
            wait = 2 * (i + 1)
            print(f"   (percobaan {i+1} gagal: {e}; tunggu {wait}s)")
            time.sleep(wait)
    return None


def license_ok(lic):
    l = lic.lower().replace("-", " ")
    if re.search(r"\b(nc|nd)\b", l):
        return False
    return any(l.startswith(p.replace("-", " ")) for p in OK_LIC)


def strip_html(s):
    return re.sub(r"<[^>]+>", "", s or "").strip()


def search(query):
    params = {
        "action": "query", "format": "json", "generator": "search",
        "gsrsearch": f"{query} filetype:bitmap", "gsrnamespace": "6", "gsrlimit": "15",
        "prop": "imageinfo", "iiprop": "url|size|mime|extmetadata", "iiurlwidth": "720",
    }
    raw = http_get(API + "?" + urllib.parse.urlencode(params))
    if not raw:
        return []
    pages = json.loads(raw).get("query", {}).get("pages", {})
    return sorted(pages.values(), key=lambda p: p.get("index", 999))


def pick(query):
    tokens = [t for t in re.findall(r"[a-zà-ÿ]+", query.lower()) if len(t) >= 3]
    for page in search(query):
        info = (page.get("imageinfo") or [None])[0]
        if not info or info.get("mime") not in ("image/jpeg", "image/png"):
            continue
        if info.get("width", 0) < 700 or info.get("height", 0) < 450:
            continue
        title = page.get("title", "").lower()
        if any(b in title for b in BAD_WORDS):
            continue
        if tokens and not any(t in title for t in tokens):
            continue
        meta = info.get("extmetadata", {})
        lic = meta.get("LicenseShortName", {}).get("value", "")
        if not license_ok(lic):
            continue
        return {
            "url": info.get("thumburl") or info.get("url"),
            "title": page["title"].replace("File:", ""),
            "author": strip_html(meta.get("Artist", {}).get("value", "")) or "Wikimedia Commons",
            "license": lic,
            "page": info.get("descriptionurl", ""),
        }
    return None


def save_webp(data, path):
    im = Image.open(io.BytesIO(data)).convert("RGB")
    if im.width > 720:
        im = im.resize((720, int(im.height * 720 / im.width)), Image.LANCZOS)
    im.save(path, "WEBP", quality=74, method=6)


def main():
    os.makedirs(IMG_DIR, exist_ok=True)
    cred_path = f"{ASSETS}/credits.json"
    credits = {}
    if os.path.exists(cred_path):
        for c in json.load(open(cred_path, encoding="utf-8")):
            credits[c["id"]] = c

    ok, missing = 0, []
    for path in sorted(glob.glob(f"{ASSETS}/recipes/*.json")):
        for r in json.load(open(path, encoding="utf-8")):
            rid, out = r["id"], f"{IMG_DIR}/{r['id']}.webp"
            if os.path.exists(out):
                ok += 1; continue
            queries = [r.get("photo", "")] + r.get("photoAlt", []) + [r["name"]]
            done = False
            for q in [q for q in queries if q]:
                print(f"[{rid}] cari: {q}")
                hit = pick(q)
                time.sleep(0.6)
                if not hit:
                    continue
                data = http_get(hit["url"])
                if not data:
                    continue
                try:
                    save_webp(data, out)
                except Exception as e:
                    print(f"   gagal konversi: {e}"); continue
                credits[rid] = {"id": rid, "title": hit["title"], "author": hit["author"],
                                "license": hit["license"], "url": hit["page"]}
                print(f"   OK -> {hit['title']} ({hit['license']})")
                ok += 1; done = True
                break
            if not done:
                missing.append(rid)

    json.dump(list(credits.values()), open(cred_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    with open("build_report.txt", "w", encoding="utf-8") as f:
        f.write(f"Foto berhasil: {ok}\nResep tanpa foto (tidak ditampilkan di aplikasi): {len(missing)}\n")
        f.write("\n".join(missing) + "\n")
    print(f"\nFoto berhasil: {ok} | tanpa foto: {len(missing)} -> {missing}")
    if ok == 0:
        print("Tidak ada foto yang berhasil diunduh (cek koneksi runner)."); sys.exit(1)


if __name__ == "__main__":
    main()
