# RECIPE BOOK – Resep Dunia (Android, offline)

Kotlin + Jetpack Compose. Semua data (JSON) dan foto (WebP) dibundel di APK; tanpa internet saat dipakai.

## Cara build di GitHub
1. Upload `RECIPE_BOOK_tahap9.zip` ke root repo tanpa diekstrak, dan buat file `.github/workflows/build-apk.yml` (isi sama dengan file `build-apk.yml`).
2. Tab Actions → Build APK → tunggu selesai → unduh artifact `RECIPE-BOOK-APK`.
3. Saat build, foto diambil otomatis dari Wikimedia Commons (lisensi terbuka). Cek artifact `laporan-foto` untuk resep yang tidak mendapat foto.

## Menambah resep
Tambah file `app/src/main/assets/recipes/recipes_NN_nama.json` (format sama dengan file yang ada, wajib isi `photo` = kata kunci pencarian foto). `tools/validate_recipes.py` memeriksa data sebelum build.
