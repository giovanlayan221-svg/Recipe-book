package com.recipebook.dunia.data

import android.content.Context
import kotlinx.serialization.json.Json

object RecipeRepository {
    private val json = Json { ignoreUnknownKeys = true }

    // Membaca semua file JSON di folder assets/recipes. Resep tanpa foto di assets/images dilewati.
    fun load(context: Context): List<Recipe> {
        val am = context.assets
        val images = am.list("images")?.toSet() ?: emptySet()
        val out = LinkedHashMap<String, Recipe>()
        val files = am.list("recipes")?.filter { it.endsWith(".json") }?.sorted() ?: emptyList()
        for (f in files) {
            val text = am.open("recipes/$f").bufferedReader().use { it.readText() }
            val list = try {
                json.decodeFromString<List<Recipe>>(text)
            } catch (e: Exception) {
                emptyList()
            }
            for (r in list) {
                if ("${r.id}.webp" in images && r.ingredients.isNotEmpty() && r.steps.isNotEmpty()) {
                    out.putIfAbsent(r.id, r)
                }
            }
        }
        return out.values.toList()
    }

    fun credits(context: Context): List<Credit> = try {
        val text = context.assets.open("credits.json").bufferedReader().use { it.readText() }
        json.decodeFromString<List<Credit>>(text)
    } catch (e: Exception) {
        emptyList()
    }
}

object RecipeSearch {
    private fun norm(s: String) = s.lowercase().trim()

    fun search(recipes: List<Recipe>, query: String): List<Recipe> {
        val q = norm(query)
        if (q.isBlank()) return emptyList()
        val words = q.split(" ").filter { it.isNotBlank() }
        return recipes
            .filter { r ->
                val hay = norm(
                    listOf(
                        r.name, r.country, r.cat.label, r.desc,
                        r.ingredients.joinToString(" ") { it.firstOrNull() ?: "" }
                    ).joinToString(" ")
                )
                words.all { hay.contains(it) }
            }
            .sortedBy { if (norm(it.name).contains(q)) 0 else 1 }
    }
}
